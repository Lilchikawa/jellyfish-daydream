// Jellyfish Daydream — small motion details for a calm, seamless-feeling loop.
// The CSS handles the looping movement; this script adds gentle, randomized bubble drift.
document.querySelectorAll(".distant-bubbles i").forEach((bubble, index) => {
  bubble.style.animationDelay = `${-index * 1.37}s`;
});
