# Jellyfish Daydream 🪼

A soft-and-cute square pixel-inspired aquarium animation for Instagram.

## Files
- `index.html` — scene structure
- `style.css` — pixel-inspired illustration and looping animation
- `script.js` — small animation setup

## Run locally
Open `index.html` in a browser.

## Publish with GitHub Pages
1. Create a new GitHub repository named `jellyfish-daydream`.
2. Upload all four files to the repository root.
3. Open **Settings → Pages**.
4. Under **Build and deployment**, choose **Deploy from a branch**.
5. Select `main` and `/ (root)`, then Save.
6. Open the Pages URL GitHub provides.

The scene is a 1:1 square composition. For an Instagram post, export or screen-record it at 1080 × 1080.
